package com.example.referenciaapa;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Configurar los botones de la actividad principal
        Button btnLibro = findViewById(R.id.btnAgregarLibro);
        Button btnRevista = findViewById(R.id.btnAgregarRevista);
        Button btnWeb = findViewById(R.id.btnAgregarWeb);
        Button btnMostrarReferencias = findViewById(R.id.btnVerReferencias);

        // Botón para agregar libro
        btnLibro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AgregarLibroActivity.class);
                startActivity(intent);
            }
        });

        // Botón para agregar revista
        btnRevista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AgregarRevistaActivity.class);
                startActivity(intent);
            }
        });

        // Botón para agregar web
        btnWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AgregarWebActivity.class);
                startActivity(intent);
            }
        });

        // Botón para mostrar referencias
        btnMostrarReferencias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MostrarReferenciasActivity.class);
                startActivity(intent);
            }
        });





        // Llamar a la función para configurar la barra de navegación
        setupBottomNavigation();
    }

    // Función para configurar la barra de navegación inferior
    private void setupBottomNavigation() {
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navigation_home) {
                    startActivity(new Intent(MainActivity.this, MainActivity.class));
                    return true;

                } else if (itemId == R.id.navigation_references) {
                    startActivity(new Intent(MainActivity.this, MostrarReferenciasActivity.class));
                    return true;
                }
                return false;
            }
        });
    }

    // Lógica para buscar referencias (puedes implementar tu lógica aquí)
    private void buscarReferencia() {
        Toast.makeText(this, "Buscar referencia", Toast.LENGTH_SHORT).show();
        // Implementar la lógica de búsqueda aquí
    }

    // Lógica para eliminar referencias (puedes implementar tu lógica aquí)
    private void eliminarReferencia() {
        Toast.makeText(this, "Eliminar referencia", Toast.LENGTH_SHORT).show();
        // Implementar la lógica de eliminación aquí
    }
}
