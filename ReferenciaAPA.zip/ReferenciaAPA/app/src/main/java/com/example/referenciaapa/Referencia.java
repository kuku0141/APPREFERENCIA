package com.example.referenciaapa;

public class Referencia {
    private int id;  // ID único de la referencia
    private String titulo;
    private String autor;
    private int ano;
    private String editorial;
    private String volumen;  // Solo para revistas
    private String numero;   // Solo para revistas
    private String url;      // Solo para documentos web

    // Constructor para libros


    // Constructor para revistas
    public Referencia(int id, String titulo, String autor, int ano, String volumen, String numero) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.ano = ano;
        this.volumen = volumen;
        this.numero = numero;
    }

    // Constructor para documentos web
    public Referencia(int id, String titulo, String autor, int ano, String url) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.ano = ano;
        this.url = url;
    }

    public Referencia(String autor, String titulo, int ano, String editorial) {
    }

    // Getters para todos los atributos
    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public int getAno() {
        return ano;
    }

    public String getEditorial() {
        return editorial;
    }

    public String getVolumen() {
        return volumen;  // Solo para revistas
    }

    public String getNumero() {
        return numero;   // Solo para revistas
    }

    public String getUrl() {
        return url;  // Solo para documentos web
    }

    // Setters (opcional, si necesitas modificar los datos después de crear el objeto)
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public void setVolumen(String volumen) {
        this.volumen = volumen;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
