package com.example.referenciaapa;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class EditarReferenciaActivity extends AppCompatActivity {

    private EditText editTextTitulo, editTextAutor, editTextAno, editTextEditorial;
    private Button buttonGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_libro);  // Usamos el layout de agregar

        // Inicializar los elementos del layout
        EditText editTextTitulo = findViewById(R.id.editTitulo);
        EditText editTextAutor = findViewById(R.id.editAutor);
        EditText editTextAno = findViewById(R.id.editAno);
        EditText editTextEditorial = findViewById(R.id.editEditorial);
        Button buttonGuardar = findViewById(R.id.btnGuardar);

        // Recibir los datos enviados
        String titulo = getIntent().getStringExtra("titulo");
        String autor = getIntent().getStringExtra("autor");
        String ano = getIntent().getStringExtra("ano");
        String editorial = getIntent().getStringExtra("editorial");

        // Pre-llenar los campos con los datos de la referencia
        editTextTitulo.setText(titulo);
        editTextAutor.setText(autor);
        editTextAno.setText(ano);
        editTextEditorial.setText(editorial);

        // Guardar los cambios (similar al ejemplo anterior)
        buttonGuardar.setOnClickListener(v -> {
            // Guardar los cambios y finalizar la actividad
            finish();
        });
}

}