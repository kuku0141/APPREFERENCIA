package com.example.referenciaapa;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AgregarLibroActivity extends AppCompatActivity {

    private EditText autor, titulo, ano, editorial, lugar;
    private Button btnGuardar;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_libro);

        // Inicializar los elementos de la vista
        autor = findViewById(R.id.editAutor);
        titulo = findViewById(R.id.editTitulo);
        ano = findViewById(R.id.editAno);
        editorial = findViewById(R.id.editEditorial);
        lugar = findViewById(R.id.editLugar);
        btnGuardar = findViewById(R.id.btnGuardar);

        dbHelper = new DatabaseHelper(this);

        // Configurar el botón para guardar datos en la base de datos
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strAutor = autor.getText().toString();
                String strTitulo = titulo.getText().toString();
                String strAno = ano.getText().toString();
                String strEditorial = editorial.getText().toString();
                String strLugar = lugar.getText().toString();

                // Validar que los campos no estén vacíos
                if (strAutor.isEmpty() || strTitulo.isEmpty() || strAno.isEmpty() || strEditorial.isEmpty() || strLugar.isEmpty()) {
                    // Mostrar mensaje de error si faltan datos
                    return;
                }

                // Guardar los datos en la base de datos
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.COLUMN_AUTOR, strAutor);
                values.put(DatabaseHelper.COLUMN_TITULO, strTitulo);
                values.put(DatabaseHelper.COLUMN_ANO, Integer.parseInt(strAno));
                values.put(DatabaseHelper.COLUMN_EDITORIAL, strEditorial);
                values.put(DatabaseHelper.COLUMN_LUGAR, strLugar);

                db.insert(DatabaseHelper.TABLE_BOOKS, null, values);
                db.close();

                // Cierra la actividad después de guardar
                finish();
            }
        });

        // Configurar la barra de navegación inferior
        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navigation_home) {
                    startActivity(new Intent(AgregarLibroActivity.this, MainActivity.class));
                    return true;
                } else if (itemId == R.id.navigation_references) {
                    startActivity(new Intent(AgregarLibroActivity.this, MostrarReferenciasActivity.class));
                    return true;
                }
                return false;
            }
        });
    }
}
