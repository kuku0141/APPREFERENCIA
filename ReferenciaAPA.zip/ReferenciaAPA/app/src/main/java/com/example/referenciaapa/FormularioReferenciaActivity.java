package com.example.referenciaapa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class FormularioReferenciaActivity extends AppCompatActivity {

    private EditText etTitulo, etAutor, etAno, etEditorial, etVolumen, etNumero, etUrl;
    private boolean esEdicion = false;
    private int referenciaId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario_referencia);

        // Inicializar campos comunes
        etTitulo = findViewById(R.id.etTitulo);
        etAutor = findViewById(R.id.etAutor);
        etAno = findViewById(R.id.etAno);
        etEditorial = findViewById(R.id.etEditorial);

        // Inicializar campos adicionales
        etVolumen = findViewById(R.id.etVolumen);  // Campo para revista
        etNumero = findViewById(R.id.etNumero);    // Campo para revista
        etUrl = findViewById(R.id.etUrl);          // Campo para documentos web

        // Recibir los datos del Intent
        Intent intent = getIntent();
        String tipoReferencia = intent.getStringExtra("tipo");
        esEdicion = intent.getBooleanExtra("esEdicion", false);
        referenciaId = intent.getIntExtra("id", -1);  // Obtener el ID de la referencia

        if (esEdicion) {
            etTitulo.setText(intent.getStringExtra("titulo"));
            etAutor.setText(intent.getStringExtra("autor"));
            etAno.setText(String.valueOf(intent.getIntExtra("ano", 0)));

            if ("libro".equals(tipoReferencia)) {
                etEditorial.setText(intent.getStringExtra("editorial"));
                etVolumen.setVisibility(View.GONE);  // Ocultar campos de revistas
                etNumero.setVisibility(View.GONE);
                etUrl.setVisibility(View.GONE);      // Ocultar campo de URL

            } else if ("revista".equals(tipoReferencia)) {
                etVolumen.setText(intent.getStringExtra("volumen"));
                etNumero.setText(intent.getStringExtra("numero"));
                etEditorial.setVisibility(View.GONE); // Ocultar campo de editorial
                etUrl.setVisibility(View.GONE);       // Ocultar campo de URL

            } else if ("web".equals(tipoReferencia)) {
                etUrl.setText(intent.getStringExtra("url"));
                etVolumen.setVisibility(View.GONE);  // Ocultar campos de revistas
                etNumero.setVisibility(View.GONE);
                etEditorial.setVisibility(View.GONE); // Ocultar campo de editorial
            }
        }

        Button btnGuardar = findViewById(R.id.btnGuardar);
        btnGuardar.setOnClickListener(v -> guardarReferencia(tipoReferencia));
    }

    private void guardarReferencia(String tipoReferencia) {
        String titulo = etTitulo.getText().toString();
        String autor = etAutor.getText().toString();
        int ano = Integer.parseInt(etAno.getText().toString());

        Intent resultIntent = new Intent();
        resultIntent.putExtra("id", referenciaId);
        resultIntent.putExtra("titulo", titulo);
        resultIntent.putExtra("autor", autor);
        resultIntent.putExtra("ano", ano);

        if ("libro".equals(tipoReferencia)) {
            String editorial = etEditorial.getText().toString();
            resultIntent.putExtra("editorial", editorial);

        } else if ("revista".equals(tipoReferencia)) {
            String volumen = etVolumen.getText().toString();
            String numero = etNumero.getText().toString();
            resultIntent.putExtra("volumen", volumen);
            resultIntent.putExtra("numero", numero);

        } else if ("web".equals(tipoReferencia)) {
            String url = etUrl.getText().toString();
            resultIntent.putExtra("url", url);
        }

        setResult(RESULT_OK, resultIntent);
        finish();
    }
}
