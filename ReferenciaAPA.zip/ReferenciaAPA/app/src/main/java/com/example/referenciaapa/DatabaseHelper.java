package com.example.referenciaapa;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "referencias.db";
    public static final int DATABASE_VERSION = 1;

    // Definición de la tabla de Libros
    public static final String TABLE_BOOKS = "libros";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_AUTOR = "autor";
    public static final String COLUMN_ANO = "ano";
    public static final String COLUMN_TITULO = "titulo";
    public static final String COLUMN_EDITORIAL = "editorial";
    public static final String COLUMN_LUGAR = "lugar";

    // Definición de la tabla de Revistas
    public static final String TABLE_JOURNALS = "revistas";
    public static final String COLUMN_VOLUMEN = "volumen";
    public static final String COLUMN_NUMERO = "numero";

    // Definición de la tabla de Documentos Web
    public static final String TABLE_WEB = "documentos_web";
    public static final String COLUMN_URL = "url";
    public static final String COLUMN_FECHA = "fecha";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Crear la tabla de libros
        String CREATE_TABLE_BOOKS = "CREATE TABLE " + TABLE_BOOKS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_AUTOR + " TEXT, " +
                COLUMN_ANO + " INTEGER, " +
                COLUMN_TITULO + " TEXT, " +
                COLUMN_EDITORIAL + " TEXT, " +
                COLUMN_LUGAR + " TEXT)";
        db.execSQL(CREATE_TABLE_BOOKS);

        // Crear la tabla de revistas
        String CREATE_TABLE_JOURNALS = "CREATE TABLE " + TABLE_JOURNALS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_AUTOR + " TEXT, " +
                COLUMN_ANO + " INTEGER, " +
                COLUMN_TITULO + " TEXT, " +
                COLUMN_EDITORIAL + " TEXT, " +
                COLUMN_LUGAR + " TEXT, " +
                COLUMN_VOLUMEN + " TEXT, " +
                COLUMN_NUMERO + " TEXT)";
        db.execSQL(CREATE_TABLE_JOURNALS);

        // Crear la tabla de documentos web
        String CREATE_TABLE_WEB = "CREATE TABLE " + TABLE_WEB + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_AUTOR + " TEXT, " +
                COLUMN_ANO + " INTEGER, " +
                COLUMN_TITULO + " TEXT, " +
                COLUMN_EDITORIAL + " TEXT, " +
                COLUMN_LUGAR + " TEXT, " +
                COLUMN_URL + " TEXT, " +
                COLUMN_FECHA + " TEXT)";
        db.execSQL(CREATE_TABLE_WEB);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_JOURNALS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEB);
        onCreate(db);
    }
}
