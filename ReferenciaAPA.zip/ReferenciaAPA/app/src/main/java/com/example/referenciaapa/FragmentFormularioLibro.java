package com.example.referenciaapa;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.referenciaapa.R;


public class FragmentFormularioLibro extends Fragment {

    private EditText etTitulo, etAutor, etAno, etEditorial;
    private Button btnGuardar;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_formulario_libro, container, false);

        // Inicializar campos de texto
        etTitulo = view.findViewById(R.id.etTitulo);
        etAutor = view.findViewById(R.id.etAutor);
        etAno = view.findViewById(R.id.etAno);
        etEditorial = view.findViewById(R.id.etEditorial);
        btnGuardar = view.findViewById(R.id.btnGuardar);

        // Lógica para guardar los datos del libro
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String titulo = etTitulo.getText().toString();
                String autor = etAutor.getText().toString();
                String ano = etAno.getText().toString();
                String editorial = etEditorial.getText().toString();

                // Puedes enviar estos datos de vuelta a la actividad o guardarlos directamente en la base de datos
            }
        });

        return view;
    }
}