package com.example.referenciaapa;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AgregarWebActivity extends AppCompatActivity {

    private EditText editTextAutor, editTextAno, editTextTitulo, editTextLugar, editTextUrl, editTextFecha;
    private Button btnGuardar;
    private DatabaseHelper dbHelper;
    private static final String TAG = "AgregarWebActivity"; // Para seguimiento en logs

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_web);  // Revisa que este archivo exista

        // Inicializar vistas
        editTextAutor = findViewById(R.id.editAutor);
        editTextAno = findViewById(R.id.editAno);
        editTextTitulo = findViewById(R.id.editTitulo);
        editTextLugar = findViewById(R.id.editLugar);
        editTextUrl = findViewById(R.id.editUrl);
        editTextFecha = findViewById(R.id.editFecha);
        btnGuardar = findViewById(R.id.btnGuardar);

        // Verificar que las vistas no sean nulas
        if (editTextAutor == null || editTextAno == null || editTextTitulo == null ||
                editTextLugar == null || editTextUrl == null || editTextFecha == null) {
            Log.e(TAG, "Uno o más campos no se han inicializado correctamente.");
            Toast.makeText(this, "Error al inicializar los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // Inicializar DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Configurar botón para guardar el documento web
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarWeb();
            }
        });
        // Configurar la barra de navegación inferior
        setupBottomNavigation();
    }

    private void guardarWeb() {
        // Obtener los valores ingresados
        String autor = editTextAutor.getText().toString().trim();
        String anoStr = editTextAno.getText().toString().trim();
        String titulo = editTextTitulo.getText().toString().trim();
        String lugar = editTextLugar.getText().toString().trim();
        String url = editTextUrl.getText().toString().trim();
        String fecha = editTextFecha.getText().toString().trim();

        // Validar que los campos no estén vacíos
        if (autor.isEmpty() || anoStr.isEmpty() || titulo.isEmpty() || lugar.isEmpty() || url.isEmpty() || fecha.isEmpty()) {
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            Log.w(TAG, "Datos incompletos: uno o más campos vacíos.");
            return;
        }

        try {
            // Convertir año a entero
            int ano = Integer.parseInt(anoStr);

            // Abrir la base de datos en modo escritura
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            // Crear un objeto ContentValues con los datos
            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.COLUMN_AUTOR, autor);
            values.put(DatabaseHelper.COLUMN_ANO, ano);
            values.put(DatabaseHelper.COLUMN_TITULO, titulo);
            values.put(DatabaseHelper.COLUMN_LUGAR, lugar);
            values.put(DatabaseHelper.COLUMN_URL, url);
            values.put(DatabaseHelper.COLUMN_FECHA, fecha);

            // Insertar los datos en la tabla de documentos web
            long newRowId = db.insert(DatabaseHelper.TABLE_WEB, null, values);

            // Verificar si la inserción fue exitosa
            if (newRowId != -1) {
                Toast.makeText(this, "Documento web guardado con éxito", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Documento web guardado con éxito. ID: " + newRowId);
            } else {
                Toast.makeText(this, "Error al guardar el documento web", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Error al insertar documento web en la base de datos.");
            }

            db.close(); // Cerrar la base de datos después de insertar

        } catch (NumberFormatException e) {
            // Manejar el error si el año no es un número válido
            Toast.makeText(this, "Año no válido", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Error: Año ingresado no es válido.", e);
        } catch (Exception e) {
            // Manejar cualquier otro error
            Toast.makeText(this, "Error al guardar el documento web", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Error general al guardar el documento web.", e);
        }
    }


    private void setupBottomNavigation() {
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navigation_home) {
                    startActivity(new Intent(AgregarWebActivity.this, MainActivity.class));
                    return true;
                } else if (itemId == R.id.navigation_references) {
                    startActivity(new Intent(AgregarWebActivity.this, MostrarReferenciasActivity.class));
                    return true;
                }
                return false;
            }
        });
    }




}
