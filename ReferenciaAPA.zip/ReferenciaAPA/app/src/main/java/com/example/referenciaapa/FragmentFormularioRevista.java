package com.example.referenciaapa;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


public class FragmentFormularioRevista extends Fragment {

    private EditText etTitulo, etAutor, etAno, etVolumen, etNumero;
    private Button btnGuardar;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_formulario_revista, container, false);

        // Inicializar campos de texto
        etTitulo = view.findViewById(R.id.etTitulo);
        etAutor = view.findViewById(R.id.etAutor);
        etAno = view.findViewById(R.id.etAno);
        etVolumen = view.findViewById(R.id.etVolumen);
        etNumero = view.findViewById(R.id.etNumero);
        btnGuardar = view.findViewById(R.id.btnGuardar);

        // Lógica para guardar los datos de la revista
        btnGuardar.setOnClickListener(v -> {
            String titulo = etTitulo.getText().toString();
            String autor = etAutor.getText().toString();
            String ano = etAno.getText().toString();
            String volumen = etVolumen.getText().toString();
            String numero = etNumero.getText().toString();

            // Puedes enviar estos datos de vuelta a la actividad o guardarlos directamente en la base de datos
        });

        return view;
    }
}
