package com.example.referenciaapa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class activity_formulario_referencia extends AppCompatActivity {

    private EditText etTitulo, etAutor, etAno, etEditorial, etUrl;
    private String tipoReferencia;  // Para saber si es "Libro", "Revista" o "Documento Web"
    private boolean esEdicion;  // Para saber si es "Agregar" o "Editar"

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario_referencia);

        etTitulo = findViewById(R.id.etTitulo);
        etAutor = findViewById(R.id.etAutor);
        etAno = findViewById(R.id.etAno);
        etEditorial = findViewById(R.id.etEditorial);
        etUrl = findViewById(R.id.etUrl);

        // Obtener los datos del Intent (tipo y si es edición)
        Intent intent = getIntent();
        tipoReferencia = intent.getStringExtra("tipo");
        esEdicion = intent.getBooleanExtra("esEdicion", false);

        // Si es un "Documento Web", muestra el campo URL
        if (tipoReferencia.equals("Documento Web")) {
            etUrl.setVisibility(View.VISIBLE);
        }

        // Si es edición, obtener los datos a editar
        if (esEdicion) {
            cargarDatosParaEdicion(intent);
        }

        // Configurar el botón de guardar
        Button btnGuardar = findViewById(R.id.btnGuardar);
        btnGuardar.setOnClickListener(v -> guardarReferencia());
    }

    // Método para cargar datos si estamos en modo edición
    private void cargarDatosParaEdicion(Intent intent) {
        String titulo = intent.getStringExtra("titulo");
        String autor = intent.getStringExtra("autor");
        int ano = intent.getIntExtra("ano", 0);
        String editorial = intent.getStringExtra("editorial");
        String url = intent.getStringExtra("url");

        etTitulo.setText(titulo);
        etAutor.setText(autor);
        etAno.setText(String.valueOf(ano));
        etEditorial.setText(editorial);

        if (tipoReferencia.equals("Documento Web")) {
            etUrl.setText(url);
        }
    }

    // Método para guardar la referencia
    private void guardarReferencia() {
        // Obtener los valores del formulario
        String titulo = etTitulo.getText().toString();
        String autor = etAutor.getText().toString();
        int ano = Integer.parseInt(etAno.getText().toString());
        String editorial = etEditorial.getText().toString();
        String url = etUrl.getText().toString();

        // Devolver los datos a la actividad anterior
        Intent resultIntent = new Intent();
        resultIntent.putExtra("titulo", titulo);
        resultIntent.putExtra("autor", autor);
        resultIntent.putExtra("ano", ano);
        resultIntent.putExtra("editorial", editorial);

        if (tipoReferencia.equals("Documento Web")) {
            resultIntent.putExtra("url", url);
        }

        setResult(RESULT_OK, resultIntent);
        finish();  // Finalizar la actividad y volver con los datos
    }
}
