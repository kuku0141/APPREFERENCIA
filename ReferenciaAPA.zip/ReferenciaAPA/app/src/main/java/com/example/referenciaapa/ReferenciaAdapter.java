package com.example.referenciaapa;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import com.example.referenciaapa.Referencia;

public class ReferenciaAdapter extends ArrayAdapter<Referencia> {
    private final Context context;
    private final List<Referencia> referencias;

    public ReferenciaAdapter(Context context, List<Referencia> referencias) {
        super(context, R.layout.list_item_referencia, referencias);
        this.context = context;
        this.referencias = referencias;
    }

    // ViewHolder para mejorar el rendimiento
    static class ViewHolder {
        TextView tvTitulo;
        TextView tvAutor;
        TextView tvAno;
        TextView tvEditorial;
        ImageButton btnEditar;
        ImageButton btnEliminar;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        View rowView = convertView;

        // Si la vista es null, la inflamos
        if (rowView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowView = inflater.inflate(R.layout.list_item_referencia, parent, false);

            // Inicializar el ViewHolder y asignar los elementos del layout
            holder = new ViewHolder();
            holder.tvTitulo = rowView.findViewById(R.id.textViewTitulo);
            holder.tvAutor = rowView.findViewById(R.id.textViewAutor);
            holder.tvAno = rowView.findViewById(R.id.textViewAno);
            holder.tvEditorial = rowView.findViewById(R.id.textViewEditorial);
            holder.btnEditar = rowView.findViewById(R.id.btnEditarReferencia);
            holder.btnEliminar = rowView.findViewById(R.id.btnEliminarReferencia);

            // Guardar el ViewHolder dentro de la vista
            rowView.setTag(holder);
        } else {
            // Reutilizamos el ViewHolder
            holder = (ViewHolder) rowView.getTag();
        }

        // Obtener la referencia actual
        Referencia referencia = referencias.get(position);

        // Asignar los datos a las vistas
        holder.tvTitulo.setText(referencia.getTitulo());
        holder.tvAutor.setText(referencia.getAutor());
        holder.tvAno.setText(String.valueOf(referencia.getAno()));
        holder.tvEditorial.setText(referencia.getEditorial());

        // Asegurarse de que los botones sean visibles
        holder.btnEditar.setVisibility(View.VISIBLE);
        holder.btnEliminar.setVisibility(View.VISIBLE);


        Log.d("ReferenciaAdapter", "btnEditarReferencia width: " + holder.btnEditar.getWidth());
        Log.d("ReferenciaAdapter", "btnEliminarReferencia width: " + holder.btnEliminar.getWidth());
        Log.d("ReferenciaAdapter", "getView() called for position: " + position);
        Log.e("ReferenciaAdapter", "btnEditarReferencia width: " + holder.btnEditar.getWidth());
        Log.e("ReferenciaAdapter", "btnEliminarReferencia width: " + holder.btnEliminar.getWidth());

        // Agregar
        //
        // funcionalidad al botón Editar
        holder.btnEditar.setOnClickListener(v -> {
            Intent intent = new Intent(context, EditarReferenciaActivity.class);
            intent.putExtra("titulo", referencia.getTitulo());
            intent.putExtra("autor", referencia.getAutor());
            intent.putExtra("ano", referencia.getAno());
            intent.putExtra("editorial", referencia.getEditorial());
            context.startActivity(intent);
        });

        // Agregar funcionalidad al botón Eliminar
        // Eliminar la referencia de la lista y actualizar el adaptador
        referencias.remove(position);
        notifyDataSetChanged();  // Actualiza la vista
        Toast.makeText(context, "Referencia eliminada", Toast.LENGTH_SHORT).show();

        return rowView;
    }

}
