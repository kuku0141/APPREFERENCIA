package com.example.referenciaapa;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.cursoradapter.widget.CursorAdapter;

import com.example.referenciaapa.DatabaseHelper;
import com.example.referenciaapa.R;

public class MultiReferenciaAdapter extends CursorAdapter {

    private static final String TAG = "MultiReferenciaAdapter";

    public MultiReferenciaAdapter(Context context, Cursor cursor, int flags) {
        super(context, cursor, flags);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        return inflater.inflate(R.layout.list_item_referencia, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView textViewTitulo = view.findViewById(R.id.textViewTitulo);
        TextView textViewAutor = view.findViewById(R.id.textViewAutor);
        TextView textViewAno = view.findViewById(R.id.textViewAno);
        TextView textViewEditorial = view.findViewById(R.id.textViewEditorial);
        ImageButton btnEditar = view.findViewById(R.id.btnEditarReferencia);

        // Asegúrate de que los nombres de las columnas coincidan con los de tu base de datos
        int tituloIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_TITULO);
        int autorIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_AUTOR);
        int anoIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_ANO);
        int editorialIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_EDITORIAL);

        // Verificar si los índices son válidos
        if (tituloIndex >= 0 && autorIndex >= 0 && anoIndex >= 0 && editorialIndex >= 0) {
            // Obtener los valores del cursor
            String titulo = cursor.getString(tituloIndex);
            String autor = cursor.getString(autorIndex);
            String ano = cursor.getString(anoIndex);
            String editorial = cursor.getString(editorialIndex);

            // Asignar los valores a los TextViews
            textViewTitulo.setText(titulo);
            textViewAutor.setText(autor);
            textViewAno.setText(ano);
            textViewEditorial.setText(editorial);

            // Configurar el botón "Editar"
            btnEditar.setOnClickListener(v -> {
                // Crear un intent para abrir la actividad de edición
                Intent intent = new Intent(context, EditarReferenciaActivity.class);

                // Pasar los datos actuales de la referencia a la actividad de edición
                intent.putExtra("titulo", titulo);
                intent.putExtra("autor", autor);
                intent.putExtra("ano", ano);
                intent.putExtra("editorial", editorial);

                // Iniciar la actividad de edición
                context.startActivity(intent);
            });
        } else {
            Log.e(TAG, "No se encontraron algunas columnas en el cursor");
        }
    }

}
