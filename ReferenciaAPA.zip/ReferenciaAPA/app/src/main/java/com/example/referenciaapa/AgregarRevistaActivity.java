package com.example.referenciaapa;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AgregarRevistaActivity extends AppCompatActivity {

    private EditText editTextAutor, editTextAno, editTextTitulo, editTextEditorial, editTextLugar, editTextVolumen, editTextNumero;
    private Button btnGuardar;
    private DatabaseHelper dbHelper;
    private static final String TAG = "AgregarRevistaActivity"; // Para seguimiento en logs

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_revista);  // Revisa que este archivo exista

        // Inicializar vistas
        editTextAutor = findViewById(R.id.editAutor);
        editTextAno = findViewById(R.id.editAno);
        editTextTitulo = findViewById(R.id.editTitulo);
        editTextEditorial = findViewById(R.id.editEditorial);
        editTextLugar = findViewById(R.id.editLugar);
        editTextVolumen = findViewById(R.id.editVolumen);
        editTextNumero = findViewById(R.id.editNumero);
        btnGuardar = findViewById(R.id.btnGuardar);

        // Verificar que las vistas no sean nulas
        if (editTextAutor == null || editTextAno == null || editTextTitulo == null ||
                editTextEditorial == null || editTextLugar == null || editTextVolumen == null ||
                editTextNumero == null) {
            Log.e(TAG, "Uno o más campos no se han inicializado correctamente.");
            Toast.makeText(this, "Error al inicializar los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // Inicializar DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Configurar botón para guardar la revista
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarRevista();
            }
        });

        // Configurar la barra de navegación inferior
        setupBottomNavigation();
    }

    private void guardarRevista() {
        // Obtener los valores ingresados
        String autor = editTextAutor.getText().toString().trim();
        String anoStr = editTextAno.getText().toString().trim();
        String titulo = editTextTitulo.getText().toString().trim();
        String editorial = editTextEditorial.getText().toString().trim();
        String lugar = editTextLugar.getText().toString().trim();
        String volumen = editTextVolumen.getText().toString().trim();
        String numero = editTextNumero.getText().toString().trim();

        // Validar que los campos no estén vacíos
        if (autor.isEmpty() || anoStr.isEmpty() || titulo.isEmpty() || editorial.isEmpty() || lugar.isEmpty() || volumen.isEmpty() || numero.isEmpty()) {
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            Log.w(TAG, "Datos incompletos: uno o más campos vacíos.");
            return;
        }

        try {
            // Convertir año a entero
            int ano = Integer.parseInt(anoStr);

            // Abrir la base de datos en modo escritura
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            // Crear un objeto ContentValues con los datos
            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.COLUMN_AUTOR, autor);
            values.put(DatabaseHelper.COLUMN_ANO, ano);
            values.put(DatabaseHelper.COLUMN_TITULO, titulo);
            values.put(DatabaseHelper.COLUMN_EDITORIAL, editorial);
            values.put(DatabaseHelper.COLUMN_LUGAR, lugar);
            values.put(DatabaseHelper.COLUMN_VOLUMEN, volumen);
            values.put(DatabaseHelper.COLUMN_NUMERO, numero);

            // Insertar los datos en la tabla de revistas
            long newRowId = db.insert(DatabaseHelper.TABLE_JOURNALS, null, values);

            // Verificar si la inserción fue exitosa
            if (newRowId != -1) {
                Toast.makeText(this, "Revista guardada con éxito", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Revista guardada con éxito. ID: " + newRowId);
            } else {
                Toast.makeText(this, "Error al guardar la revista", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Error al insertar revista en la base de datos.");
            }

            db.close(); // Cerrar la base de datos después de insertar

        } catch (NumberFormatException e) {
            // Manejar el error si el año no es un número válido
            Toast.makeText(this, "Año no válido", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Error: Año ingresado no es válido.", e);
        } catch (Exception e) {
            // Manejar cualquier otro error
            Toast.makeText(this, "Error al guardar la revista", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Error general al guardar la revista.", e);
        }
    }

    private void setupBottomNavigation() {
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navigation_home) {
                    startActivity(new Intent(AgregarRevistaActivity.this, MainActivity.class));
                    return true;
                } else if (itemId == R.id.navigation_references) {
                    startActivity(new Intent(AgregarRevistaActivity.this, MostrarReferenciasActivity.class));
                    return true;
                }
                return false;
            }
        });
    }






}
