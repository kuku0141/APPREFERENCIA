package com.example.referenciaapa;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.referenciaapa.R;

public class MostrarReferenciasActivity extends AppCompatActivity {

    private ListView listViewLibros, listViewRevistas, listViewDocumentosWeb;
    private DatabaseHelper dbHelper;
    private EditText etBuscar;
    private List<Referencia> referencias;
    private ReferenciaAdapter referenciaAdapter;
    private int editedPosition;
    private List<Referencia> listaLibros;
    private List<Referencia> listaRevistas;
    private List<Referencia> listaDocumentosWeb;
    EditText etTitulo, etAutor, etAno, etEditorial;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_referencias);
        referencias = new ArrayList<>();  // <- Asegúrate de inicializar la lista aquí

        // Inicializar ListViews
        listViewLibros = findViewById(R.id.listViewLibros);
        listViewRevistas = findViewById(R.id.listViewRevistas);
        listViewDocumentosWeb = findViewById(R.id.listViewDocumentosWeb);

        listaLibros = new ArrayList<>();
        listaRevistas = new ArrayList<>();
        listaDocumentosWeb = new ArrayList<>();
 


        // Registrar el menú contextual para los ListView
        registerForContextMenu(listViewLibros);
        registerForContextMenu(listViewRevistas);
        registerForContextMenu(listViewDocumentosWeb);


        Intent intent = getIntent();
        String tipoReferencia = intent.getStringExtra("tipo");

        // Verificar el tipo de referencia
        if ("libro".equals(tipoReferencia)) {
            // Campos para libro
            etEditorial.setVisibility(View.VISIBLE);  // Mostrar campo editorial
            // Otros campos específicos de libros

        } else if ("revista".equals(tipoReferencia)) {
            // Campos para revista
            etEditorial.setVisibility(View.GONE);  // Ocultar campo editorial
            // Mostrar campos específicos para revistas (volumen, numero)

        } else if ("web".equals(tipoReferencia)) {
            // Campos para documentos web
            etEditorial.setVisibility(View.GONE);  // Ocultar campo editorial
            // Mostrar campos específicos para documentos web (URL)
        }


        // Inicializar el adaptador con la lista vacía de referencias
        referenciaAdapter = new ReferenciaAdapter(this, referencias);
        listViewLibros.setAdapter(referenciaAdapter);

        // Configurar el botón de regreso
        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(view -> finish());

        // Inicializar el campo de búsqueda
        etBuscar = findViewById(R.id.etBuscar);
        dbHelper = new DatabaseHelper(this);

        // Agregar un TextWatcher para realizar la búsqueda en tiempo real
        etBuscar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // No se necesita implementar
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Llamar al método de búsqueda cada vez que cambie el texto
                buscarReferencias(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // No se necesita implementar
            }
        });
        cargarReferencias();
        // Cargar los datos iniciales
        mostrarLibros();
        Log.d("MostrarReferencias", "Número de referencias cargadas: " + referencias.size());

        mostrarRevistas();
        mostrarDocumentosWeb();
    }
    private void cargarReferencias() {
        referencias.clear(); // Limpia la lista
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_BOOKS, null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String autor = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_AUTOR));
                String titulo = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_TITULO));
                int ano = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ANO));
                String editorial = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EDITORIAL));

                Referencia referencia = new Referencia(autor, titulo, ano, editorial);
                referencias.add(referencia);
            } while (cursor.moveToNext());

            Log.d("MostrarReferencias", "Número de referencias cargadas: " + referencias.size());
            referenciaAdapter.notifyDataSetChanged();
        } else {
            Log.d("MostrarReferencias", "No se encontraron referencias en la base de datos.");
        }

        if (cursor != null) {
            cursor.close();
        }
    }





    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);

        // Verifica si la lista de referencias está vacía
        if (!referencias.isEmpty()) {
            Log.d("ContextMenu", "Número de referencias: " + referencias.size());
        } else {
            Log.d("ContextMenu", "La lista de referencias está vacía.");
        }
    }

    //metodo de seteo de contexto menu en el activity de mostrar referencias
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int position = info.position;
        Referencia referencia = referencias.get(position);

        if (item.getItemId() == R.id.menueditar_libro) {
            // Editar libro
            Intent intent = new Intent(this, FormularioReferenciaActivity.class);
            intent.putExtra("esEdicion", true);
            intent.putExtra("id", referencia.getId());  // ID de la referencia
            intent.putExtra("titulo", referencia.getTitulo());
            intent.putExtra("autor", referencia.getAutor());
            intent.putExtra("ano", referencia.getAno());
            intent.putExtra("editorial", referencia.getEditorial());
            intent.putExtra("tipo", "libro");  // Tipo de referencia (libro)
            startActivityForResult(intent, 1);

        } else if (item.getItemId() == R.id.menueditar_revista) {
            // Editar revista
            Intent intent = new Intent(this, FormularioReferenciaActivity.class);
            intent.putExtra("esEdicion", true);
            intent.putExtra("id", referencia.getId());  // ID de la referencia
            intent.putExtra("titulo", referencia.getTitulo());
            intent.putExtra("autor", referencia.getAutor());
            intent.putExtra("ano", referencia.getAno());
            intent.putExtra("volumen", referencia.getVolumen());  // Si tienes estos campos adicionales
            intent.putExtra("numero", referencia.getNumero());    // Para las revistas
            intent.putExtra("tipo", "revista");  // Tipo de referencia (revista)
            startActivityForResult(intent, 1);

        } else if (item.getItemId() == R.id.menueditar_web) {
            // Editar documento web
            Intent intent = new Intent(this, FormularioReferenciaActivity.class);
            intent.putExtra("esEdicion", true);
            intent.putExtra("id", referencia.getId());  // ID de la referencia
            intent.putExtra("titulo", referencia.getTitulo());
            intent.putExtra("autor", referencia.getAutor());
            intent.putExtra("ano", referencia.getAno());
            intent.putExtra("url", referencia.getUrl());  // Para documentos web
            intent.putExtra("tipo", "web");  // Tipo de referencia (documento web)
            startActivityForResult(intent, 1);
        }

        return super.onContextItemSelected(item);
    }

    // Mostrar todos los libros inicialmente
    private void mostrarLibros() {
        buscarLibros("");  // Muestra todos los libros inicialmente
    }
    private void mostrarRevistas() {
        buscarRevistas("");  // Muestra todas las revistas inicialmente
    }
    private void mostrarDocumentosWeb() {
        buscarDocumentosWeb("");  // Muestra todos los documentos web inicialmente
    }
    // Método de búsqueda principal
    private void buscarReferencias(String textoBuscar) {
        referencias.clear();  // Limpiar la lista antes de realizar la búsqueda

        // Buscar en las tres categorías (libros, revistas, documentos web)
        buscarLibros(textoBuscar);
        buscarRevistas(textoBuscar);
        buscarDocumentosWeb(textoBuscar);

        referenciaAdapter.notifyDataSetChanged();  // Notificar al adaptador
    }



    // Buscar libros en la base de datos y mostrarlos en el ListView
    private void buscarLibros(String textoBuscar) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Aquí colocas el código para verificar las columnas de la tabla "libros"
        Cursor columnCursor = db.rawQuery("PRAGMA table_info(" + DatabaseHelper.TABLE_BOOKS + ")", null);


        Cursor cursor = db.query(DatabaseHelper.TABLE_BOOKS, null, "titulo LIKE ?", new String[]{"%" + textoBuscar + "%"}, null, null, null);

        if (cursor != null && cursor.getCount() > 0) {
            ArrayList<String> referencias = new ArrayList<>();
            while (cursor.moveToNext()) {
                String autor = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_AUTOR));
                String titulo = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_TITULO));
                String ano = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ANO));
                String editorial = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EDITORIAL));


                String referenciaAPA = autor + " (" + ano + "). *" + titulo + "*. " + editorial + ".";
                referencias.add(referenciaAPA);
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, referencias);
            listViewLibros.setAdapter(adapter);
            cursor.close();
        } else {
            listViewLibros.setAdapter(null);  // Limpia la lista si no hay resultados
        }
    }



    // Buscar revistas en la base de datos y mostrarlas en el ListView
    private void buscarRevistas(String textoBuscar) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_JOURNALS, null, "titulo LIKE ?", new String[]{"%" + textoBuscar + "%"}, null, null, null);

        if (cursor != null && cursor.getCount() > 0) {
            ArrayList<String> referencias = new ArrayList<>();
            while (cursor.moveToNext()) {
                int autorIndex = cursor.getColumnIndex("autor");
                int tituloIndex = cursor.getColumnIndex("titulo");
                int anoIndex = cursor.getColumnIndex("ano");
                int volumenIndex = cursor.getColumnIndex("volumen");
                int numeroIndex = cursor.getColumnIndex("numero");

                if (autorIndex != -1 && tituloIndex != -1 && anoIndex != -1 && volumenIndex != -1 && numeroIndex != -1) {
                    String autor = cursor.getString(autorIndex);
                    String titulo = cursor.getString(tituloIndex);
                    String ano = cursor.getString(anoIndex);
                    String volumen = cursor.getString(volumenIndex);
                    String numero = cursor.getString(numeroIndex);

                    String referenciaAPA = autor + " (" + ano + "). " + titulo + ". *Revista*, " + volumen + "(" + numero + ").";
                    referencias.add(referenciaAPA);
                }
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, referencias);
            listViewRevistas.setAdapter(adapter);

            cursor.close();
        } else {
            listViewRevistas.setAdapter(null);  // Limpia la lista si no hay resultados
        }
    }


    // Buscar documentos web en la base de datos y mostrarlos en el ListView
    private void buscarDocumentosWeb(String textoBuscar) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_WEB, null, "titulo LIKE ?", new String[]{"%" + textoBuscar + "%"}, null, null, null);

        if (cursor != null && cursor.getCount() > 0) {
            ArrayList<String> referencias = new ArrayList<>();
            while (cursor.moveToNext()) {
                int autorIndex = cursor.getColumnIndex("autor");
                int tituloIndex = cursor.getColumnIndex("titulo");
                int anoIndex = cursor.getColumnIndex("ano");
                int urlIndex = cursor.getColumnIndex("url");

                if (autorIndex != -1 && tituloIndex != -1 && anoIndex != -1 && urlIndex != -1) {
                    String autor = cursor.getString(autorIndex);
                    String titulo = cursor.getString(tituloIndex);
                    String ano = cursor.getString(anoIndex);
                    String url = cursor.getString(urlIndex);

                    String referenciaAPA = autor + " (" + ano + "). " + titulo + ". Recuperado de " + url;
                    referencias.add(referenciaAPA);
                }
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, referencias);
            listViewDocumentosWeb.setAdapter(adapter);

            cursor.close();
        } else {
            listViewDocumentosWeb.setAdapter(null);  // Limpia la lista si no hay resultados
        }
    }







    private void eliminarReferencia(int position) {
        new AlertDialog.Builder(this)
                .setTitle("Confirmar eliminación")
                .setMessage("¿Estás seguro de que deseas eliminar esta referencia?")
                .setPositiveButton(android.R.string.yes, (dialog, which) -> {
                    referencias.remove(position);
                    referenciaAdapter.notifyDataSetChanged();
                    Toast.makeText(this, "Referencia eliminada", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.no, null)
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            int id = data.getIntExtra("id", -1);
            String titulo = data.getStringExtra("titulo");
            String autor = data.getStringExtra("autor");
            int ano = data.getIntExtra("ano", 0);
            String editorial = data.getStringExtra("editorial");

            actualizarReferencia(id, titulo, autor, ano, editorial);
        }
    }

    private void actualizarReferencia(int id, String titulo, String autor, int ano, String editorial) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_TITULO, titulo);
        values.put(DatabaseHelper.COLUMN_AUTOR, autor);
        values.put(DatabaseHelper.COLUMN_ANO, ano);
        values.put(DatabaseHelper.COLUMN_EDITORIAL, editorial);

        db.update(DatabaseHelper.TABLE_BOOKS, values, DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        cargarReferencias();
    }

}